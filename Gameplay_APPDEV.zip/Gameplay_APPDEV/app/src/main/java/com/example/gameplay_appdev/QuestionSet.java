package com.example.gameplay_appdev;

public interface QuestionSet {
    String[] getQuestions();

    String[][] getChoices();

    String[] getAnswers();


}
